/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modal;

import aleefah.Aleefah;
import java.util.ArrayList;
import java.util.List;
import modal.Animal;

/**
 *
 * @author Alaa Abdullah
 */
public class Globalvariables {
   public static     List<Animal> animals = new ArrayList<>();
   public static int user_id = Aleefah.userId;
}
