/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aleefah;

import modal.Animal;

/**
 *
 * @author wedfa
 */
public interface MyListener {
    public void onClickListener(Animal animal);
}
